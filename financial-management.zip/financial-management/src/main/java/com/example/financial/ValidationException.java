package com.example.financial;

public class ValidationException extends Exception {
    public ValidationException(String message) {
        super(message);
    }
}