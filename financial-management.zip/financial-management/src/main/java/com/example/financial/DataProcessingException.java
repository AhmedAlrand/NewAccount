package com.example.financial;

public class DataProcessingException extends DatabaseException {
    public DataProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
